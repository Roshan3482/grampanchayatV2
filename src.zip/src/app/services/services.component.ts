import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css']
})
export class ServicesComponent implements OnInit {

  public services = [
    {title: 'Service 1', subtitle: 'Special for today', image: 'assets/images/others/Home 1.jpg'},
    {title: 'Service 2', subtitle: 'New Arrivals On Sale', image: 'assets/images/others/Home 2.jpg'},
    {title: 'Service 3', subtitle: 'Special for today', image: 'assets/images/carousel/banner3.jpg'},
    {title: 'Service 4', subtitle: 'New Arrivals On Sale', image: 'assets/images/carousel/banner4.jpg'},
    {title: 'Service 5', subtitle: 'Special for today', image: 'assets/images/carousel/banner5.jpg'},
];

  constructor() { }

  ngOnInit(): void {
  }

}
